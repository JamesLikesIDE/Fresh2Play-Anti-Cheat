package net.fresh2play.plugins.F2PAC.checks;

public enum Level {
	
	PROBALY, DEFINITELY, PASSED;

}
