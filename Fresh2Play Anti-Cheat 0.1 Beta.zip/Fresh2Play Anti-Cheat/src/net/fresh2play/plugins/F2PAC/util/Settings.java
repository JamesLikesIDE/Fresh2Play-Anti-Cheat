package net.fresh2play.plugins.F2PAC.util;

public class Settings {

	public static final Double MAX_XZ_SPEED = 0.66D; // Adjustable
	public static final String notify = "f2pac.notify";
	public static final String DONE = "passed";
	
}


